// list of enums

enum TextSizes { small , medium , large }

enum OrderStatus { processing , shipped , delivered}

enum PaymentMethod { paypal , googlePay , applePay , masterCard , visa , creditCard , paystack , razorPay , paytm}