import 'package:ecommerce/app.dart';
import 'package:flutter/material.dart';

void main(

    ) {
  // widgets binding
  //init local storage
  //await native splash
  //initiliaze firebase
  //initialize authentication


  runApp(const App(
  ));
}

